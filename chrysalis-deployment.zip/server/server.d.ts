import { server } from './app';
export default server;
//# sourceMappingURL=server.d.ts.map