import { server } from './app-simple';
export default server;
//# sourceMappingURL=server-simple.d.ts.map