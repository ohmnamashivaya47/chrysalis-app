declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=qr.d.ts.map